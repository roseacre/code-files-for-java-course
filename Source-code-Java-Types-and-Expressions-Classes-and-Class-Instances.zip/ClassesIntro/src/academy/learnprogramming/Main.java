package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        Car myCar = new Car();
        Car anotherCar = new Car();

        myCar.accelerate();
        anotherCar.brake();
    }
}

class Car {

    public void accelerate() {
        System.out.println("You are going faster.");
    }

    public void brake() {
        System.out.println("You are going slower.");
    }
}
