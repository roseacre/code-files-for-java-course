package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {
        System.out.printf("byte minimum= %s, maximum= %s%n", Byte.MIN_VALUE, Byte.MAX_VALUE);
        System.out.printf("short minimum= %s, maximum= %s%n", Short.MIN_VALUE, Short.MAX_VALUE);

        System.out.printf("int minimum= %s, maximum= %s%n", Integer.MIN_VALUE, Integer.MAX_VALUE);
        System.out.printf("long minimum= %s, maximum= %s%n", Long.MIN_VALUE, Long.MAX_VALUE);

        System.out.printf("float minimum= %s, maximum= %s%n", Float.MIN_VALUE, Float.MAX_VALUE);
        System.out.printf("double minimum= %s, maximum= %s%n", Double.MIN_VALUE, Double.MAX_VALUE);

//        340282350000000000000000000000000000000
//        1,797,693,134,862,320,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,
//                000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000
//        000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,
//                000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000
//        000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000
    }
}
