package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        Car myCar = new Car("Tim's car");
        Car anotherCar = new Car("The Batmobile");

        myCar.accelerate();
        myCar.accelerate();
        myCar.accelerate();
        myCar.accelerate();
        myCar.brake();
        myCar.accelerate();

        anotherCar.brake();
    }
}

class Car {

    private int speed = 0;
    private String name;

    public Car(String carName) {
        name = carName;
    }

    public void accelerate() {
        speed++;
        System.out.printf("%s is going %d kilometres per hour.%n", name, speed);
    }

    public void brake() {
        speed--;
        System.out.printf("%s is going %d kilometres per hour.%n", name, speed);
    }
}
