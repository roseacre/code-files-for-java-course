package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        int answer = (7 + 3) * 4;
        System.out.println(answer);
    }
}
