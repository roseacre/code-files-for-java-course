package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {
        System.out.printf("byte minimum= %s, maximum= %s%n", Byte.MIN_VALUE, Byte.MAX_VALUE);
        System.out.printf("short minimum= %s, maximum= %s%n", Short.MIN_VALUE, Short.MAX_VALUE);
        System.out.printf("int minimum= %s, maximum= %s%n", Integer.MIN_VALUE, Integer.MAX_VALUE);
        System.out.printf("long minimum= %s, maximum= %s%n", Long.MIN_VALUE, Long.MAX_VALUE);

    }
}
