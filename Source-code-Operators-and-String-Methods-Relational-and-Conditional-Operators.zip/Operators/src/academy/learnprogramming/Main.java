package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        int second = 31;
        int minute = 1;

        if ((minute < 59) && ((second + 1) > 59)) {
            minute++;
        }
    }
}
